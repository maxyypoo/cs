merge(list1: sortedList*, list2: sortedList*) : void
{
list3 : sortedList* 
n : int
for (pos 1 to getlength.list1) 
{
list3 ->insert(list1.getEntry(n))

}

for (pos 1 to getlength.list2 ) 
{
list3 ->insert(list2.getEntry(n))

}this goto auto enum; using namespace; while if do else switch case break continue default for public private template class; 