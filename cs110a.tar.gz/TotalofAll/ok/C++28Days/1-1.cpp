#include <iostream>

int main ()
{
  using std::cout;
  
  cout << "I love C++ \n";
  
  return 0;
}