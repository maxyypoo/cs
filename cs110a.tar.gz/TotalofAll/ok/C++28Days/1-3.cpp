#include <iostream>

int main ()
{
  std::cout << "Is there a bug here?";
}