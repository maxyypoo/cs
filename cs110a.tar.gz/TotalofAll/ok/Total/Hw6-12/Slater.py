fName = 'Joe'
lName = 'Slater'
age = 42
print 'His name is, ', lName, ', ', fName, ' and his age is, ', age, '.'