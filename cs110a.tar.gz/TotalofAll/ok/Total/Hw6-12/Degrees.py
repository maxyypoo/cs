Celcius = 24
Fahrenheit = (Celcius * float(9) / 5) + 32
print'Its 24 degrees Celcius outside, which is', Fahrenheit, ' degrees in Fahrenheit'
print('\n')
