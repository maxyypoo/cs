phrase = 'Echo '
print phrase * 3