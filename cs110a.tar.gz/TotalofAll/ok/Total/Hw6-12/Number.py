numberHigh = 100
numberLow = 50
numberTotal = numberHigh + numberLow
print 'Variable 1 = ', numberHigh
print 'Variable 2 = ', numberLow
print 'Total = ', numberTotal
print 'All the values are, ', numberHigh, ', ', numberLow, ', ', numberTotal