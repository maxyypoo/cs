name = raw_input('Please enter your name: ')
grade1, grade2, grade3 = input('Please enter 3 grades: '), input(), input()
gradeAvg = (grade1 + grade2 + grade3) / float(3)
print 'Hi', name, ', your grade average is ', gradeAvg
