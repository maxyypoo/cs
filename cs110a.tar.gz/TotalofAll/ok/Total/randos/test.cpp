#include <iostream>
using namespace std;

int main()
{
  int const NUMBERS = 4;
  int numeros[NUMBERS] = {1, 5, 3, 9};
  
  cout << numeros << endl;
  
  return 0;
}