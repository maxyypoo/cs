Pass='Dodoseko12345600-'
print(Pass)



