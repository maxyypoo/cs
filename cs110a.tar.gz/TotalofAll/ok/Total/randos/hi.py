x = 0
y = 'I think the fuck not you trick ass bitch'
while(x < 3 ):
  print y * 2
  x += 1
print("NNhasdfads  sadfsf") [3:9]
list1 = ["hello", 'not so much', 5, 125, 'plesaf']
print(list1)
print(list1)[2:16]
print(list1) + [55]
print(list1) + [y]
chup = ('ola','nana',9000, 'machbar')
chup + tuple(y)
print(chup)