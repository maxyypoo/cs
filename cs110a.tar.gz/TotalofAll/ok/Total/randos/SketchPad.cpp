#include <iostream>
using namespace std;

int main ()
{
  int values[] = {2, 6, 10, 14};
  cout << values[++x];
}