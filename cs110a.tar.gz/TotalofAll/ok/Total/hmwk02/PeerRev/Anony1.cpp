//file: hw02.cpp
//assignment: hw02:hi
//description: A simple program to demo
//compiling and submitting C++ code. 

#include <iostream>
using namespace std;

int main () //main function here
{
  cout << "hello world"  << endl;
  return 0;
}

/*
[tpan7@hills hmwk02]$ ./a.out
hello world
[tpan7@hills hmwk02]$ 
*/