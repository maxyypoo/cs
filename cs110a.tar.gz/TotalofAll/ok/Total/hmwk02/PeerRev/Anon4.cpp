// Filename: hw02_Hi.cpp
// Description: A simple demostration of
// console output.

#include <iostream>
using namespace std;

int main()
{
  cout << "hello world"  << endl;
  return 0;
}
/*
computer can't see this
[clo19@hills hmwk02]$ ./a.out
hello world
[clo19@hills hmwk02]$ 

*/