// Filename: hw2_hi.cpp
// Description: A simple demonstration of console output.

#include <iostream>
using namespace std;

int main()
{
  cout << "hello world" << endl;
  return 0;
}

/*
[kcheun15@hills hw2]$ ./a.out
hello world
[kcheun15@hills hw2]$
*/