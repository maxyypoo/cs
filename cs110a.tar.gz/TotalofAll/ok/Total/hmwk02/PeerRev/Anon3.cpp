  /*
Filename: hello.cpp
Assignment: CS110A PP1: Hi
Description: Simple Hello World program
  */

#include <iostream>
using namespace std;

int main() //main function here
{
  cout <<"Hello, World!" << endl; //Display the string
  return 0;
}

  /*
[atse14@hills hmwk02]$ ./a.out
Hello, World!
[atse14@hills hmwk02]$
  */