/*
Filename: Hw002.ccp
Assignment: Hw02: Hi
Description: A simple program to practice console out (cout) command, with the purpose of demonstrating compiling in C++ (g++ thorough Shell).
*/

#include <iostream>
using namespace std; 

int main() //main function, no var. 
{
  cout << "Hello World" << endl;
  return 0;
}
/*
[dakpinar@hills hmwk02]$ ./a.out
Hello World
[dakpinar@hills hmwk02]$ ./a.out
*/
