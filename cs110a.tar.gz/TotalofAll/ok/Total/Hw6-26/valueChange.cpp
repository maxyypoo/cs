//Input
  cout << setprecision(2) << fixed;
  cout << "Please enter the loan amount: $";
  cin >> loanAmount;
  cout << "Please enter the monthly interest rate: ";
  cin >> monthlyInterestRate;
  cout << "Please enter the number of payments: ";
  cin >> numberOfPayments;