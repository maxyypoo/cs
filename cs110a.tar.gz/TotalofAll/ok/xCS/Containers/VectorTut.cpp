#include <iostream>
#include <stdlib.h>
#include <vector>

using namespace std;

int main ()
{
  vector <char> stringOfNames;
  stringOfNames.reserve(100000);
  
  return 0;
}