void showArray(const int array[], int size)
  {
    for (int count = 0; count < size; count++)
      cout << array[count] << " ";
    cout << endl;
  }