#include <iostream>
#include "person.h"


using namespace std;

int main ()
{
  Person kewlDude(25 ,"kewl", " Dude");
  
  kewlDude.print();
 
  return 0;
}