void showArray(const char* str1, int size)
  {
    for (int count = 0; count < size; count++)
      cout << str1[count] << " ";
    cout << endl;
  }