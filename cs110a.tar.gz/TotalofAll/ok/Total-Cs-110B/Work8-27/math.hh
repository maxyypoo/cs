namespace numeros
{
  int numeroUno = 5, numeroDos = 7;
}
