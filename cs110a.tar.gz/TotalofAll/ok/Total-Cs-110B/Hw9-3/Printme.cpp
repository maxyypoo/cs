#include <iostream>
#include "printme.h"

void printMe()
{
 
  std::cout << "Hello World\n"; 
  
}