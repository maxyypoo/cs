/* 
Console_____

import java.io.*;

Console con = System.Console();

System.out.print("Your name please:");

String name = con.readLine();
System.out.println("Hello" + name);


######################################

*/

//Demo Program **
/*
import java.io.*;

class HelloConsole
{
 public static void main(String ... args)
 {
    
  
  String name = System.console().readLine("Your name Please: ");
  
  System.out.println("Hello " + name);
  
  }
}
*/
//Demo Program ## Parse Method (works with double and stuff as well)
/*import java.io.*;
class DoubleIt
{
  public static void main(String ... args)
  {
    Console con = System.console();
    String num = con.readLine("your number please: ");
    
    int inum = Integer.parseInt(num);
    
    System.out.println(inum*2);
  }
}*/

//Print functions
/*public static void println(Object obj)
{
  System.out.println("" + obj);
  
}

public static void print(Object obj)
{
  System.out.print("" + obj);
  
}

*/

//Array Decleration
/*
int num[] = new int[4];
*/











