charAt(int loc);
str.charAt(3);

Character class;

isUpper;
isLower;
isDigit;

Character.isDigit(str.charAt(3));
all boolean;


Hw3:

Ssnum Validation;
Interactively type your social, then the program should find out if the ss is valid or not. Do it with infinite for loop, look for "end", "stop" or "quit" to end the program;

name.trip();
name.strip();
stripLeading();
stripTrailing();


index Of methods;
indexOf();
lastIndexOf();
indexOf(String str, int after);
if it cannot find a target, returns -1;


public static String repeat (String str, int n)
{
  return n > 0 ? str+repeat(str, --n);
}

