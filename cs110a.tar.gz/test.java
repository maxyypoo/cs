class test
{
  public static void doubleIt (int num[])
  {
    for (int i = 0; i < num.length;i++)
    {
      num[i] = 2*num[i];
    }
  }
    public static void main (String ... args)
    {
      int num[] = {5,7,3,11,8};
      System.out.println ("before");
      for (int n: num) System.out.println(n);
      doubleIt(num);
      System.out.println("after");
      for(int n:num) System.out.println(n);
    }
    
    
  }



Do brd with chew, lolpos, fuzzy?, 2 dps or a tank/dps comp;
2-3 hours, start with int spams, go to arena spams, to anger spams, to golemlord spams;
if we reach that point before we end the sesh, we do full run(s);

Mara, do with whoever group, kill princess and res;

UBRS/LBRS comes later;
Scholo/Strat comes later;


get chew to 60! with some to all bis;
get chew to be the designated enchanter, reputation and low-mid tier dung grind for greens and blues;